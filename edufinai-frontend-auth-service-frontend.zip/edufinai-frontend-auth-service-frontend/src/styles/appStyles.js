const palette = {
  app: 'var(--surface-app)',
  card: 'var(--surface-card)',
  elevated: 'var(--surface-elevated)',
  muted: 'var(--surface-muted)',
  textPrimary: 'var(--text-primary)',
  textSecondary: 'var(--text-secondary)',
  textMuted: 'var(--text-muted)',
  border: 'var(--border-subtle)',
  borderStrong: 'var(--border-strong)',
  primary: 'var(--color-primary)',
  primarySoft: 'var(--color-primary-soft)',
  primaryStrong: 'var(--color-primary-strong)',
  primaryGlow: 'var(--color-primary-glow)',
  success: 'var(--color-success)',
  warning: 'var(--color-warning)',
  danger: 'var(--color-danger)',
  info: 'var(--color-info)',
  secondary: 'var(--color-secondary)',
};

const transitions = {
  soft: 'var(--transition-soft)',
  pop: 'var(--transition-pop)',
  fade: 'var(--transition-fade)',
};

const spacing = {
  xxs: 'var(--space-2xs)',
  xs: 'var(--space-xs)',
  sm: 'var(--space-sm)',
  md: 'var(--space-md)',
  lg: 'var(--space-lg)',
  xl: 'var(--space-xl)',
  xxl: 'var(--space-2xl)',
};

const radius = {
  sm: 'var(--radius-sm)',
  md: 'var(--radius-md)',
  lg: 'var(--radius-lg)',
  full: 'var(--radius-full)',
};

const typography = {
  base: 'var(--font-family-sans)',
  display: 'var(--font-family-display)',
};

const cardBase = {
  backgroundColor: palette.card,
  border: `1px solid ${palette.border}`,
  borderRadius: radius.md,
  padding: spacing.lg,
  boxShadow: 'var(--shadow-xs)',
  transition: `transform ${transitions.soft}, box-shadow ${transitions.soft}, border-color ${transitions.soft}`,
};

const softCard = {
  ...cardBase,
  backgroundColor: palette.muted,
  border: `1px solid ${palette.border}`,
  boxShadow: 'none',
};

const frostedCard = {
  ...cardBase,
  background: palette.elevated,
  boxShadow: 'var(--shadow-sm)',
  backdropFilter: 'blur(18px)',
};

const interactiveCard = {
  ...cardBase,
  cursor: 'pointer',
};

const textMuted = {
  color: palette.textSecondary,
};

const pill = {
  borderRadius: radius.full,
  padding: `${spacing.xxs} ${spacing.sm}`,
  fontSize: 'var(--font-size-xs)',
  fontWeight: 600,
  backgroundColor: palette.primarySoft,
  color: palette.primary,
};

const buttonBase = {
  borderRadius: radius.md,
  padding: `${spacing.sm} ${spacing.lg}`,
  fontWeight: 600,
  fontSize: 'var(--font-size-md)',
  border: 'none',
  cursor: 'pointer',
  transition: `transform ${transitions.soft}, box-shadow ${transitions.soft}, background ${transitions.soft}`,
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: spacing.xs,
};

const primaryButton = {
  ...buttonBase,
  backgroundImage: 'var(--gradient-brand)',
  color: '#fff',
  boxShadow: 'var(--shadow-sm)',
};

const outlineButton = {
  ...buttonBase,
  backgroundColor: 'transparent',
  border: `1px solid ${palette.border}`,
  color: palette.textPrimary,
};

const ghostButton = {
  ...buttonBase,
  backgroundColor: 'transparent',
  color: palette.textSecondary,
};

export const styles = {
  app: {
    minHeight: '100vh',
    backgroundColor: palette.app,
    fontFamily: typography.base,
    paddingBottom: 'var(--bottom-nav-height, 90px)',
    transition: `background ${transitions.fade}`,
  },
  main: {
    maxWidth: 'var(--app-max-width, 640px)',
    margin: '0 auto',
    backgroundColor: 'transparent',
    minHeight: '100vh',
    padding: 'var(--main-padding, 0px)',
    borderRadius: 'var(--main-border-radius, 0px)',
    boxShadow: 'var(--main-box-shadow, none)',
    transition: 'max-width 0.3s ease, padding 0.3s ease, box-shadow 0.3s ease',
  },
  page: {
    width: '100%',
    maxWidth: 'var(--page-max-width, 1240px)',
    margin: '0 auto',
    padding: 'var(--page-padding-y, 16px) var(--page-padding-x, 16px) var(--page-padding-bottom, 28px)',
    display: 'flex',
    flexDirection: 'column',
    gap: 'var(--section-gap, 24px)',
    boxSizing: 'border-box',
  },
  responsiveGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(var(--layout-grid-columns, 1), minmax(0, 1fr))',
    gap: 'var(--layout-grid-gap, 24px)',
    alignItems: 'flex-start',
  },
  responsiveColumn: {
    display: 'flex',
    flexDirection: 'column',
    gap: 'var(--section-gap, 24px)',
  },
  responsiveFullWidth: {
    gridColumn: '1 / -1',
  },
  header: {
    marginBottom: 0,
    display: 'flex',
    justifyContent: 'space-between',
    gap: spacing.md,
    flexWrap: 'wrap',
    alignItems: 'flex-start',
  },
  headerTitle: {
    fontSize: 'var(--font-size-2xl)',
    fontWeight: 700,
    margin: 0,
    color: palette.textPrimary,
    fontFamily: typography.display,
    letterSpacing: '-0.02em',
  },
  headerSubtitle: {
    ...textMuted,
    fontSize: 'var(--font-size-sm)',
    margin: 0,
  },
  bottomNav: {
    position: 'var(--bottom-nav-position, fixed)',
    bottom: 'var(--bottom-nav-offset, 0px)',
    left: 'var(--bottom-nav-left, 50%)',
    transform: 'var(--bottom-nav-translate, translateX(-50%))',
    maxWidth: 'var(--bottom-nav-width, 640px)',
    width: 'min(100%, var(--bottom-nav-width, 640px))',
    height: '76px',
    display: 'flex',
    justifyContent: 'space-around',
    alignItems: 'center',
    border: `1px solid ${palette.border}`,
    boxShadow: 'var(--shadow-md)',
    zIndex: 1000,
    borderRadius: 'var(--bottom-nav-radius, 0px)',
    padding: 'var(--bottom-nav-padding, 0 16px)',
    backdropFilter: 'blur(18px)',
    background: palette.elevated,
  },
  navButton: {
    background: 'none',
    border: 'none',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: spacing.xxs,
    cursor: 'pointer',
    padding: `${spacing.xs} ${spacing.md}`,
    color: palette.textMuted,
    transition: `color ${transitions.soft}`,
  },
  navButtonActive: {
    color: palette.primary,
  },
  navLabel: {
    fontSize: 'var(--font-size-xs)',
    fontWeight: 600,
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
  },
  balanceCard: {
    ...frostedCard,
    backgroundImage: 'var(--gradient-brand)',
    color: '#fff',
    border: 'none',
    boxShadow: 'var(--shadow-md)',
  },
  balanceLabel: {
    fontSize: 'var(--font-size-sm)',
    opacity: 0.88,
    margin: 0,
  },
  balanceAmount: {
    fontSize: 'var(--font-size-2xl)',
    fontWeight: 700,
    margin: `${spacing.sm} 0`,
    letterSpacing: '-0.02em',
  },
  balanceStats: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '16px',
    flexWrap: 'wrap',
    width: '100%',
  },
  statLabel: {
    ...textMuted,
    fontSize: 'var(--font-size-xs)',
    margin: 0,
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
  },
  statValue: {
    fontSize: 'var(--font-size-lg)',
    fontWeight: 600,
    margin: `${spacing.xxs} 0 0`,
  },
  quickActions: {
    display: 'grid',
    gridTemplateColumns: 'repeat(var(--quick-actions-columns, 2), minmax(0, 1fr))',
    gap: spacing.sm,
    marginBottom: spacing.xl,
    width: '100%',
  },
  quickActionBtn: {
    ...interactiveCard,
    padding: spacing.lg,
    color: palette.textPrimary,
    background: `linear-gradient(135deg, ${palette.card}, ${palette.muted})`,
    border: `1px solid ${palette.border}`,
    boxShadow: 'var(--shadow-xs)',
    display: 'flex',
    alignItems: 'center',
    gap: spacing.md,
    minHeight: '88px',
  },
  quickActionIconWrap: {
    ...pill,
    backgroundColor: palette.primarySoft,
    color: palette.primary,
    fontSize: '18px',
    padding: spacing.xs,
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  section: {
    marginBottom: 0,
    display: 'flex',
    flexDirection: 'column',
    gap: spacing.md,
  },
  sectionHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: spacing.md,
  },
  sectionTitle: {
    fontSize: 'var(--font-size-lg)',
    fontWeight: 600,
    margin: 0,
    color: palette.textPrimary,
  },
  sectionSubtitle: {
    ...textMuted,
    fontSize: 'var(--font-size-sm)',
    margin: 0,
  },
  goalCard: {
    ...cardBase,
    marginBottom: spacing.sm,
  },
  goalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '8px',
  },
  goalTitle: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    color: palette.textPrimary,
  },
  goalAmount: {
    fontSize: 'var(--font-size-sm)',
    color: palette.primary,
    fontWeight: 600,
  },
  progressBar: {
    width: '100%',
    height: '8px',
    backgroundColor: palette.border,
    borderRadius: radius.full,
    overflow: 'hidden',
    position: 'relative',
  },
  progressFill: {
    height: '100%',
    backgroundImage: 'var(--gradient-brand)',
    borderRadius: radius.full,
    transition: 'width 0.4s ease',
    boxShadow: `0 4px 12px ${palette.primaryGlow}`,
  },
  transactionItem: {
    ...cardBase,
    display: 'flex',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    flexWrap: 'wrap',
  },
  transactionIcon: {
    fontSize: '24px',
  },
  transactionInfo: {
    flex: 1,
  },
  transactionCategory: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    margin: '0 0 4px 0',
    color: palette.textPrimary,
  },
  transactionDate: {
    fontSize: 'var(--font-size-xs)',
    color: palette.textMuted,
    margin: 0,
  },
  transactionAmount: {
    fontSize: 'var(--font-size-md)',
    fontWeight: 600,
  },
  transactionAmountPositive: {
    color: palette.success,
  },
  transactionAmountNegative: {
    color: palette.danger,
  },
  aiTip: {
    display: 'flex',
    gap: spacing.md,
    alignItems: 'flex-start',
    padding: spacing.lg,
    borderRadius: radius.md,
    background: 'var(--ai-card-background)',
    border: '1px solid var(--ai-card-border)',
    color: 'var(--ai-card-foreground)',
    boxShadow: 'var(--shadow-xs)',
  },
  aiTipTitle: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    margin: 0,
    color: 'var(--ai-card-foreground)',
  },
  aiTipText: {
    fontSize: 'var(--font-size-sm)',
    color: 'var(--ai-card-foreground-muted)',
    margin: `${spacing.xs} 0 0`,
    lineHeight: 1.5,
  },
  tabNav: {
    display: 'flex',
    gap: spacing.xs,
    marginBottom: spacing.lg,
    backgroundColor: palette.muted,
    borderRadius: radius.md,
    padding: spacing.xs,
  },
  tabButton: {
    ...ghostButton,
    flex: 1,
    borderRadius: radius.sm,
    border: 'none',
    fontSize: 'var(--font-size-sm)',
  },
  tabButtonActive: {
    backgroundColor: palette.card,
    color: palette.textPrimary,
    boxShadow: 'var(--shadow-xs)',
  },
  addButton: {
    ...primaryButton,
    width: '100%',
    marginBottom: spacing.lg,
    fontSize: 'var(--font-size-md)',
  },
  expenseItem: {
    ...cardBase,
    display: 'flex',
    justifyContent: 'space-between',
    padding: spacing.lg,
    marginBottom: spacing.sm,
  },
  expenseLeft: {
    display: 'flex',
    flexDirection: 'column',
    gap: spacing.xs,
  },
  expenseCategory: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    color: palette.textPrimary,
  },
  expenseNote: {
    ...textMuted,
    fontSize: 'var(--font-size-sm)',
  },
  expenseDate: {
    fontSize: 'var(--font-size-xs)',
    color: palette.textMuted,
  },
  expenseAmount: {
    fontSize: 'var(--font-size-lg)',
    fontWeight: 600,
  },
  goalCardLarge: {
    ...cardBase,
    padding: spacing.xl,
    marginBottom: spacing.lg,
  },
  goalStatus: {
    display: 'flex',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  goalStatusText: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    color: palette.primary,
  },
  goalCardTitle: {
    fontSize: 'var(--font-size-xl)',
    fontWeight: 600,
    margin: `0 0 ${spacing.md} 0`,
    color: palette.textPrimary,
  },
  goalProgress: {
    display: 'flex',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  goalPercent: {
    fontSize: 'var(--font-size-lg)',
    fontWeight: 600,
    color: palette.primary,
    minWidth: '56px',
    textAlign: 'right',
  },
  goalDetails: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: 'var(--font-size-sm)',
    color: palette.textMuted,
  },
  chartCard: {
    ...cardBase,
    marginBottom: spacing.lg,
  },
  chartTitle: {
    fontSize: 'var(--font-size-md)',
    fontWeight: 600,
    margin: `0 0 ${spacing.md} 0`,
    color: palette.textPrimary,
  },
  progressCard: {
    ...cardBase,
    marginBottom: spacing.xl,
  },
  progressLabel: {
    ...textMuted,
    fontSize: 'var(--font-size-sm)',
    margin: `0 0 ${spacing.md} 0`,
  },
  progressStats: {
    display: 'grid',
    gridTemplateColumns: 'repeat(var(--progress-stats-columns, 3), minmax(0, 1fr))',
    gap: spacing.md,
    textAlign: 'center',
  },
  progressNumber: {
    fontSize: 'var(--font-size-xl)',
    fontWeight: 700,
    color: palette.primary,
    margin: '0 0 4px 0',
  },
  progressText: {
    fontSize: 'var(--font-size-xs)',
    color: palette.textMuted,
    margin: 0,
  },
  lessonCard: {
    ...interactiveCard,
    display: 'flex',
    alignItems: 'center',
    gap: spacing.lg,
    padding: spacing.lg,
    marginBottom: spacing.sm,
  },
  lessonBadge: {
    fontSize: '32px',
  },
  lessonContent: {
    flex: 1,
  },
  lessonTitle: {
    fontSize: 'var(--font-size-md)',
    fontWeight: 600,
    margin: `0 0 ${spacing.xs} 0`,
    color: palette.textPrimary,
  },
  lessonProgress: {
    ...textMuted,
    fontSize: 'var(--font-size-sm)',
    margin: 0,
  },
  quizCard: {
    ...cardBase,
    border: `1px solid ${palette.warning}`,
    background: `linear-gradient(135deg, rgba(251, 191, 36, 0.16), ${palette.card})`,
    display: 'flex',
    alignItems: 'center',
    gap: spacing.lg,
  },
  quizTitle: {
    fontSize: 'var(--font-size-md)',
    fontWeight: 600,
    margin: `0 0 ${spacing.xs} 0`,
    color: palette.textPrimary,
  },
  quizText: {
    ...textMuted,
    fontSize: 'var(--font-size-sm)',
    margin: 0,
  },
  quizButton: {
    ...outlineButton,
    borderColor: palette.warning,
    color: palette.warning,
    whiteSpace: 'nowrap',
  },
  statsCard: {
    display: 'grid',
    gridTemplateColumns: 'repeat(var(--stats-grid-columns, 3), minmax(0, 1fr))',
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },
  statBox: {
    ...softCard,
    alignItems: 'center',
    display: 'flex',
    flexDirection: 'column',
    gap: spacing.xs,
    textAlign: 'center',
  },
  challengeCard: {
    ...cardBase,
    marginBottom: spacing.sm,
  },
  challengeHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  challengeTitle: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    margin: 0,
    color: palette.textPrimary,
  },
  challengeReward: {
    fontSize: 'var(--font-size-sm)',
    color: palette.primary,
    fontWeight: 600,
  },
  challengeProgress: {
    display: 'flex',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.xs,
  },
  challengeText: {
    fontSize: 'var(--font-size-xs)',
    color: palette.textMuted,
    minWidth: '48px',
    textAlign: 'right',
  },
  challengeType: {
    fontSize: 'var(--font-size-xs)',
    color: palette.textMuted,
  },
  leaderboardItem: {
    ...cardBase,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.md,
    marginBottom: spacing.xs,
  },
  leaderboardItemMe: {
    backgroundColor: palette.primarySoft,
    border: `1px solid ${palette.primary}`,
  },
  leaderboardLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: spacing.md,
  },
  leaderboardRank: {
    fontSize: 'var(--font-size-md)',
    fontWeight: 700,
    minWidth: '32px',
  },
  leaderboardAvatar: {
    fontSize: '24px',
  },
  leaderboardName: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 500,
    color: palette.textPrimary,
  },
  leaderboardPoints: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    color: palette.primary,
  },
  profileCard: {
    ...cardBase,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  profileAvatar: {
    fontSize: '64px',
    marginBottom: spacing.sm,
  },
  profileName: {
    fontSize: 'var(--font-size-lg)',
    fontWeight: 700,
    margin: `0 0 ${spacing.xs} 0`,
    color: palette.textPrimary,
  },
  profileLevel: {
    ...textMuted,
    fontSize: 'var(--font-size-sm)',
    margin: 0,
  },
  aiCard: {
    display: 'flex',
    flexDirection: 'column',
    gap: spacing.xs,
    padding: spacing.lg,
    borderRadius: radius.lg,
    border: '1px solid var(--ai-card-border)',
    background: 'var(--ai-card-background)',
    color: 'var(--ai-card-foreground)',
    boxShadow: 'var(--shadow-xs)',
    marginBottom: spacing.sm,
  },
  aiCardTitle: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    margin: `0 0 ${spacing.xs} 0`,
    color: 'var(--ai-card-foreground)',
  },
  aiCardText: {
    fontSize: 'var(--font-size-sm)',
    margin: 0,
    lineHeight: 1.6,
    color: 'var(--ai-card-foreground-muted)',
  },
  menuItem: {
    ...interactiveCard,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.md,
    marginBottom: spacing.xs,
    width: '100%',
  },
  menuLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: spacing.md,
  },
  menuIcon: {
    fontSize: '20px',
  },
  menuLabel: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 500,
    color: palette.textPrimary,
  },
  logoutButton: {
    ...buttonBase,
    width: '100%',
    backgroundColor: palette.danger,
    color: '#fff',
    marginTop: spacing.lg,
    boxShadow: 'var(--shadow-xs)',
  },
  infoCard: {
    ...cardBase,
    padding: spacing.lg,
  },
  infoRow: {
    display: 'flex',
    padding: `${spacing.md} 0`,
    borderBottom: `1px solid ${palette.border}`,
    gap: spacing.md,
  },
  infoLabel: {
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    color: palette.textMuted,
    minWidth: '140px',
  },
  infoValue: {
    fontSize: 'var(--font-size-sm)',
    color: palette.textPrimary,
    flex: 1,
  },
  authWrapper: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 'clamp(24px, 6vw, 64px)',
    position: 'relative',
    overflow: 'hidden',
    isolation: 'isolate',
    background: 'radial-gradient(circle at center, var(--login-gradient-core) 0%, var(--login-gradient-ring) 40%, var(--login-gradient-sheen) 75%, var(--surface-app) 100%)',
    backgroundSize: '220% 220%',
    animation: 'loginBackgroundShift 45s ease-in-out infinite',
  },
  authBackdrop: {
    position: 'absolute',
    inset: '-30%',
    background: 'radial-gradient(circle, var(--login-gradient-core) 0%, var(--login-gradient-ring) 38%, transparent 78%)',
    filter: 'blur(140px)',
    opacity: 0.85,
    animation: 'loginPulse 18s ease-in-out infinite',
    pointerEvents: 'none',
    zIndex: 0,
  },
  authBackdropGlow: {
    position: 'absolute',
    inset: '-15%',
    background: 'radial-gradient(circle, rgba(255, 255, 255, 0.5) 0%, transparent 60%)',
    filter: 'blur(100px)',
    animation: 'loginPulseReverse 24s ease-in-out infinite',
    pointerEvents: 'none',
    zIndex: 0,
  },
  authSpectrum: {
    position: 'absolute',
    width: '160vmax',
    height: '160vmax',
    background:
      'conic-gradient(' +
      'from var(--login-spectrum-angle), ' +
      '#ff3366 0%, ' +
      '#ff5e2b 8%, ' +
      '#ffb347 16%, ' +
      '#ffd633 24%, ' +
      '#d4ff33 32%, ' +
      '#79ff33 40%, ' +
      '#33ff66 48%, ' +
      '#33ffc4 56%, ' +
      '#33b9ff 64%, ' +
      '#335bff 72%, ' +
      '#7d33ff 80%, ' +
      '#ff33f1 90%, ' +
      '#ff3366 100%' +
      ')',
    opacity: 'var(--login-spectrum-alpha)',
    mixBlendMode: 'screen',
    filter: 'blur(120px)',
    animation:
      'loginSpectrumSweep 180s linear infinite, loginSpectrumSpin 240s linear infinite, loginHueCycle 260s linear infinite',
    pointerEvents: 'none',
    zIndex: 0,
  },
  authCard: {
    ...frostedCard,
    width: '100%',
    maxWidth: '420px',
    padding: spacing.xl,
    position: 'relative',
    zIndex: 1,
  },
  authTitle: {
    fontSize: 'var(--font-size-xl)',
    fontWeight: 700,
    margin: `0 0 ${spacing.xs} 0`,
    color: palette.textPrimary,
  },
  authSubtitle: {
    ...textMuted,
    fontSize: 'var(--font-size-sm)',
    lineHeight: 1.6,
    margin: `0 0 ${spacing.lg} 0`,
  },
  authForm: {
    display: 'flex',
    flexDirection: 'column',
    gap: spacing.md,
    marginTop: spacing.sm,
  },
  authField: {
    display: 'flex',
    flexDirection: 'column',
    gap: spacing.xs,
  },
  authDoubleField: {
    display: 'flex',
    gap: spacing.md,
    flexWrap: 'wrap',
  },
  authLabel: {
    fontSize: 'var(--font-size-xs)',
    color: palette.textMuted,
    fontWeight: 600,
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
  },
  authInput: {
    width: '100%',
    padding: `${spacing.sm} ${spacing.md}`,
    borderRadius: radius.sm,
    border: `1px solid ${palette.border}`,
    fontSize: 'var(--font-size-sm)',
    transition: `border-color ${transitions.soft}, box-shadow ${transitions.soft}`,
    outline: 'none',
    backgroundColor: 'transparent',
  },
  authHint: {
    fontSize: 'var(--font-size-xs)',
    color: palette.textMuted,
    margin: `${spacing.xxs} 0 0 0`,
  },
  authButton: {
    ...primaryButton,
    width: '100%',
    fontSize: 'var(--font-size-md)',
  },
  authBypassButton: {
    ...outlineButton,
    width: '100%',
    borderStyle: 'dashed',
    fontSize: 'var(--font-size-sm)',
  },
  authFooter: {
    marginTop: spacing.lg,
    fontSize: 'var(--font-size-xs)',
    color: palette.textMuted,
    textAlign: 'center',
  },
  authLink: {
    color: palette.primary,
    fontWeight: 600,
    textDecoration: 'none',
  },
  authLinkInline: {
    color: palette.primary,
    fontWeight: 600,
    textDecoration: 'none',
  },
  authNotice: {
    backgroundColor: palette.primarySoft,
    borderRadius: radius.sm,
    padding: `${spacing.sm} ${spacing.md}`,
    fontSize: 'var(--font-size-sm)',
    color: palette.primary,
    marginBottom: spacing.md,
  },
  authError: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderRadius: radius.sm,
    padding: `${spacing.sm} ${spacing.md}`,
    fontSize: 'var(--font-size-sm)',
    color: palette.danger,
    marginBottom: spacing.md,
  },
  refreshButton: {
    ...outlineButton,
    borderColor: 'transparent',
    backgroundColor: palette.primarySoft,
    color: palette.primary,
    fontSize: 'var(--font-size-sm)',
    padding: `${spacing.xs} ${spacing.md}`,
  },
  refreshButtonDisabled: {
    opacity: 0.6,
    cursor: 'not-allowed',
  },
  /* Skeleton & Loading */
  skeletonLine: {
    width: '100%',
    height: '14px',
    borderRadius: radius.full,
    background: `linear-gradient(90deg, ${palette.muted} 0%, ${palette.elevated} 50%, ${palette.muted} 100%)`,
    backgroundSize: '200% 100%',
    animation: 'shimmer 1.8s infinite linear',
  },
  skeletonCircle: {
    width: '48px',
    height: '48px',
    borderRadius: radius.full,
    background: `linear-gradient(90deg, ${palette.muted} 0%, ${palette.elevated} 50%, ${palette.muted} 100%)`,
    backgroundSize: '200% 100%',
    animation: 'shimmer 1.8s infinite linear',
  },
  skeletonCard: {
    ...cardBase,
    display: 'flex',
    flexDirection: 'column',
    gap: spacing.md,
  },
  /* Divider */
  dividerAccent: {
    height: '1px',
    background: `linear-gradient(90deg, transparent 0%, ${palette.primary} 50%, transparent 100%)`,
    margin: `${spacing.lg} 0`,
    opacity: 0.3,
  },
  /* Pill meter for progress visualization */
  pillMeter: {
    display: 'flex',
    alignItems: 'center',
    gap: spacing.xs,
    padding: `${spacing.xs} ${spacing.sm}`,
    borderRadius: radius.full,
    backgroundColor: palette.muted,
    fontSize: 'var(--font-size-xs)',
    fontWeight: 600,
  },
  pillMeterFill: {
    height: '4px',
    borderRadius: radius.full,
    backgroundImage: 'var(--gradient-brand)',
    transition: 'width 0.4s ease',
  },
  /* Radial progress */
  radialProgress: {
    position: 'relative',
    width: '80px',
    height: '80px',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radialProgressSvg: {
    transform: 'rotate(-90deg)',
  },
  radialProgressText: {
    position: 'absolute',
    fontSize: 'var(--font-size-sm)',
    fontWeight: 600,
    color: palette.textPrimary,
  },
  /* Theme Customizer */
  themeCard: {
    ...cardBase,
    padding: spacing.xl,
    marginBottom: spacing.xl,
  },
  themeSectionHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  themeSectionTitle: {
    fontSize: 'var(--font-size-lg)',
    fontWeight: 600,
    margin: 0,
    color: palette.textPrimary,
  },
  themeSectionSubtitle: {
    ...textMuted,
    fontSize: 'var(--font-size-sm)',
    margin: 0,
  },
  themeOptionRow: {
    display: 'flex',
    gap: spacing.sm,
    flexWrap: 'wrap',
    marginBottom: spacing.lg,
  },
  themeOptionButton: {
    ...outlineButton,
    flex: 1,
    minWidth: '160px',
    justifyContent: 'flex-start',
    flexDirection: 'column',
    alignItems: 'flex-start',
    gap: spacing.xxs,
    borderRadius: radius.md,
    padding: `${spacing.sm} ${spacing.lg}`,
  },
  themeOptionActive: {
    borderColor: palette.primary,
    boxShadow: `0 0 0 2px ${palette.primaryGlow}`,
    color: palette.textPrimary,
    backgroundColor: palette.primarySoft,
  },
  themeAccentGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
    gap: spacing.sm,
  },
  accentButton: {
    ...outlineButton,
    flexDirection: 'column',
    alignItems: 'flex-start',
    position: 'relative',
  },
  accentButtonActive: {
    borderColor: palette.primary,
    boxShadow: `0 0 0 2px ${palette.primaryGlow}`,
  },
  accentSwatch: {
    width: '100%',
    height: '40px',
    borderRadius: radius.sm,
    marginBottom: spacing.xs,
  },
  accentLabel: {
    fontSize: 'var(--font-size-xs)',
    color: palette.textMuted,
    textTransform: 'uppercase',
    letterSpacing: '0.04em',
  },
  toggleRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.lg,
  },
  toggleLabel: {
    fontSize: 'var(--font-size-sm)',
    color: palette.textPrimary,
    fontWeight: 600,
  },
  toggleSwitch: {
    width: '52px',
    height: '28px',
    borderRadius: radius.full,
    backgroundColor: palette.border,
    border: 'none',
    position: 'relative',
    cursor: 'pointer',
    transition: `background ${transitions.soft}`,
  },
  toggleSwitchActive: {
    backgroundColor: palette.primary,
  },
  toggleKnob: {
    position: 'absolute',
    top: '3px',
    left: '3px',
    width: '22px',
    height: '22px',
    borderRadius: radius.full,
    backgroundColor: '#fff',
    transition: `transform ${transitions.soft}`,
  },
  toggleKnobActive: {
    transform: 'translateX(24px)',
  },
};

export default styles;

