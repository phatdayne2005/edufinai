export const AUTH_ENABLED = process.env.REACT_APP_AUTH_ENABLED !== 'false';

