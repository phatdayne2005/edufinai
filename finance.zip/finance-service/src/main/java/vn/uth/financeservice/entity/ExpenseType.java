package vn.uth.financeservice.entity;

public enum ExpenseType {
    INCOME, EXPENSE
}
