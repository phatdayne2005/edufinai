package vn.uth.financeservice.entity;

public enum GoalStatus {
    ACTIVE, COMPLETED, FAILED
}
